# Website SMP Negeri 3 Kalikajar

Website resmi SMP Negeri 3 Kalikajar yang dibangun dengan PHP dan MySQL.

## Fitur

- Landing page modern dan responsif
- Panel admin terpisah
- Sistem multi-role (Admin, Guru, Siswa, Ketua Kelas, Guru BK)
- Sistem absensi terintegrasi
- PPDB Online
- Manajemen konten sekolah

## Persyaratan Sistem

- PHP 7.4 atau lebih tinggi
- MySQL 5.7 atau lebih tinggi
- Apache/Nginx web server
- Browser modern (Chrome, Firefox, Safari)

## Instalasi

1. Clone repository ini ke direktori web server Anda
2. Buat database MySQL dengan nama `smpn3kalikajar`
3. Import file SQL dari folder `database/`
4. Konfigurasi database di file `includes/config.php`
5. Pastikan folder `uploads/` memiliki hak akses write
6. Akses website melalui browser

## Struktur Direktori

```
smpn3kalikajar/
├── index.php         <-- Landing page
├── login.php
├── logout.php
├── /admin/           <-- Dashboard Admin
├── /guru/            <-- Dashboard Guru
├── /bk/              <-- Dashboard Guru BK
├── /ketuakelas/      <-- Dashboard Ketua Kelas
├── /siswa/           <-- Dashboard Siswa
├── /ppdb/            <-- Halaman/form pendaftaran
├── /includes/        <-- File konfigurasi dan koneksi database
├── /adminlte/        <-- Template dashboard AdminLTE
├── /assets/          <-- Asset publik (CSS, JS, images)
└── /uploads/         <-- Direktori upload file
```

## Lisensi

MIT License - Copyright (c) 2025 SMP Negeri 3 Kalikajar
