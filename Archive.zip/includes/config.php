<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'smpnkali_admin');
define('DB_PASS', 'BQid#}DdT780X]VC');
define('DB_NAME', 'smpnkali_db');

// Base URL configuration
$base_url = "https://smpn3kalikajar.sch.id";

// Session configuration
session_start();

// Error reporting for development
define('DEBUG', true);
if (DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}
?>
