<?php
// Script untuk mempersiapkan file untuk deployment di cPanel

// 1. Buat zip file untuk upload
$zip = new ZipArchive();
$zip_file = 'smpn3kalikajar.zip';

// 2. Tentukan file dan folder yang perlu diupload
$files_to_include = [
    'index.php',
    'login.php',
    'logout.php',
    'includes/',
    'admin/',
    'guru/',
    'bk/',
    'ketuakelas/',
    'siswa/',
    'ppdb/',
    'uploads/',
    'assets/',
    '.htaccess',
    'DEPLOYMENT.md'
];

// 3. Buat zip file
if ($zip->open($zip_file, ZipArchive::CREATE) === TRUE) {
    // Tambahkan file dan folder
    foreach ($files_to_include as $file) {
        if (is_file($file)) {
            $zip->addFile($file);
        } elseif (is_dir($file)) {
            addDirectoryToZip($file, $zip);
        }
    }
    $zip->close();
    echo "Zip file created successfully: $zip_file\n";
} else {
    die("Could not create zip file");
}

// Fungsi untuk menambahkan folder ke zip
function addDirectoryToZip($dir, $zip) {
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir),
        RecursiveIteratorIterator::LEAVES_ONLY
    );

    foreach ($files as $file) {
        if (!$file->isDir()) {
            $filePath = $file->getRealPath();
            $relativePath = substr($filePath, strlen($dir) + 1);
            $zip->addFile($filePath, $relativePath);
        }
    }
}

// 4. Buat file konfigurasi cPanel
$cpanel_config = [
    'database_name' => 'smpn3kalikajar',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_general_ci',
    'php_version' => '7.4',
    'permissions' => [
        'uploads' => '755',
        'cache' => '755',
        'config.php' => '644',
        'db.php' => '644'
    ]
];

// 5. Buat file konfigurasi untuk cPanel
file_put_contents('cpanel_config.json', json_encode($cpanel_config, JSON_PRETTY_PRINT));

echo "Deployment preparation completed!\n";
?>
