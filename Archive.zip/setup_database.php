<?php
require_once 'includes/config.php';
require_once 'includes/db.php';

$db = new Database();
$conn = $db->connect();

try {
    // Create database if not exists
    $conn->exec("CREATE DATABASE IF NOT EXISTS smpn3kalikajar");
    $conn->exec("USE smpn3kalikajar");

    // Read and execute schema
    $schema = file_get_contents('database/schema.sql');
    $conn->exec($schema);

    // Insert initial admin user
    $password = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (username, password, nama_lengkap, email, role_id, is_active) 
                          VALUES ('admin', ?, 'Administrator', 'admin@smpn3kalikajar.sch.id', 1, 1)");
    $stmt->execute([$password]);

    // Insert some sample classes
    $classes = [
        ['nama_kelas' => 'VII A', 'tingkat' => '7', 'jurusan' => 'Reguler'],
        ['nama_kelas' => 'VII B', 'tingkat' => '7', 'jurusan' => 'Reguler'],
        ['nama_kelas' => 'VIII A', 'tingkat' => '8', 'jurusan' => 'Reguler'],
        ['nama_kelas' => 'VIII B', 'tingkat' => '8', 'jurusan' => 'Reguler'],
        ['nama_kelas' => 'IX A', 'tingkat' => '9', 'jurusan' => 'Reguler'],
        ['nama_kelas' => 'IX B', 'tingkat' => '9', 'jurusan' => 'Reguler']
    ];

    foreach ($classes as $class) {
        $stmt = $conn->prepare("INSERT INTO kelas (nama_kelas, tingkat, jurusan) 
                              VALUES (?, ?, ?)");
        $stmt->execute([$class['nama_kelas'], $class['tingkat'], $class['jurusan']]);
    }

    // Insert sample subjects
    $subjects = [
        ['nama_mapel' => 'Bahasa Indonesia', 'kkm' => 70],
        ['nama_mapel' => 'Matematika', 'kkm' => 70],
        ['nama_mapel' => 'Bahasa Inggris', 'kkm' => 70],
        ['nama_mapel' => 'IPA', 'kkm' => 70],
        ['nama_mapel' => 'IPS', 'kkm' => 70],
        ['nama_mapel' => 'PKN', 'kkm' => 70]
    ];

    foreach ($subjects as $subject) {
        $stmt = $conn->prepare("INSERT INTO mapel (nama_mapel, kkm) VALUES (?, ?)");
        $stmt->execute([$subject['nama_mapel'], $subject['kkm']]);
    }

    echo "Database setup completed successfully!\n";
    echo "Initial admin credentials:\n";
    echo "Username: admin\n";
    echo "Password: admin123\n";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
