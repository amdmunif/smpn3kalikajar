#!/bin/bash

# Set permissions for uploads directory
chmod -R 755 uploads

# Create .htaccess for Apache
if [ ! -f .htaccess ]; then
    cat > .htaccess << 'EOL'
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]

# Prevent directory listing
Options -Indexes

# Protect sensitive files
<FilesMatch "^(config|db|setup).*">
    Order allow,deny
    Deny from all
</FilesMatch>
EOL
fi

# Create nginx configuration
if [ ! -f nginx.conf ]; then
    cat > nginx.conf << 'EOL'
server {
    listen 80;
    server_name localhost;
    root /path/to/your/project;
    index index.php index.html;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.(php)$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    location ~* \.(js|css|png|jpg|jpeg|gif|ico)$ {
        expires max;
        log_not_found off;
    }

    # Security
    location ~* \.ht {
        deny all;
    }

    location ~* /(config|db|setup).* {
        deny all;
    }
}
EOL
fi

# Set permissions for setup files
chmod 755 setup_database.php setup_web_server.sh

# Display setup instructions
echo "Setup completed!"
echo "1. Run setup_database.php to create database and initial data"
echo "2. Configure your web server using nginx.conf or .htaccess"
echo "3. Update database credentials in config.php if needed"
echo "4. Access the website through your web browser"

# Create symbolic link for easy access
ln -sfn "$PWD" "~/Sites/spentika"
echo "Created symbolic link in ~/Sites/spentika"
